# SocketIO test
----
A small test where:
  - mobile device can connect to port 3000 mobile.html
  - turn on or off the devices screen by clicking.

## install
Nodes dependencies
~~~~
npm install 
~~~~
frontend dependencies
~~~~
cd public
bower install
~~~~
